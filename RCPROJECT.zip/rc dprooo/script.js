const container = document.getElementById('container');
const registerBtn = document.getElementById('register');
const optionMenu = document.querySelector(".select-menu"),
       selectBtn = optionMenu.querySelector(".select-btn"),
       options = optionMenu.querySelectorAll(".option"),
       sBtn_text = optionMenu.querySelector(".sBtn-text");
const loginBtn = document.getElementById('login');

registerBtn.addEventListener('click', () => {
    selectBtn.addEventListener("click", () => optionMenu.classList.toggle("active"));  
    container.classList.add("active");
});
options.forEach(option =>{
    option.addEventListener("click", ()=>{
        let selectedOption = option.querySelector(".option-text").innerText;
        sBtn_text.innerText = selectedOption;

        optionMenu.classList.remove("active");
    });
});
loginBtn.addEventListener('click', () => {
    container.classList.remove("active");
});
    
